﻿using System;

namespace assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[1-3] <nr of rows> <nr of columns>");
                return;
            }
            int numberOfRows =  int.Parse(args[0]);
            int numberOfColumns =  int.Parse(args[1]);
            Program myProgram = new Program();
            myProgram.Start(numberOfRows, numberOfColumns);
        }
        void Start(int numberOfRows, int numberOfColumns)
        {
            int[,] matrix = new int[numberOfRows, numberOfColumns];
            InitMatrixLinear(matrix);
            //InitMatrix2D(matrix);
           // DisplayMatrix(matrix);


            DisplayMatrixWithCross(matrix);
        }
        void InitMatrix2D(int[,] matrix)
        {
            int counter = 1;
            for (int rows = 0; rows < matrix.GetLength(0); rows++)
            {
                for ( int columns = 0; columns < matrix.GetLength(1); columns++)
                {
                    matrix[rows, columns] = counter;
                    counter++;
                }

            }
        }
        void DisplayMatrix(int[,] matrix)
        {
            for (int rows = 0; rows < matrix.GetLength(0); rows++)
            {
                for (int columns = 0; columns < matrix.GetLength(1); columns++)
                {
                    Console.Write($"{ matrix[rows, columns],2 } " );
                }
                Console.WriteLine();

            }
        }
        void InitMatrixLinear(int[,] matrix)
        {
            for (int numbers = 0; numbers < matrix.Length; numbers++)
            {
                int row = numbers / matrix.GetLength(1);
                int column = numbers % matrix.GetLength(1);
                matrix[row, column] = numbers + 1;
            }
        }
        void DisplayMatrixWithCross(int[,] matrix)
        {
            for (int rows = 0; rows < matrix.GetLength(0); rows++)
            {
                for (int columns = 0; columns < matrix.GetLength(1); columns++)
                {
                    Console.ResetColor();
                    if (rows-columns==0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    if(rows+columns+1==matrix.GetLength(1))
                    {
                        Console.BackgroundColor = ConsoleColor.Yellow;
                    }
                    Console.Write(string.Format("{0, 4}", matrix[rows, columns] + " "));
                }
                Console.WriteLine();
            }
            Console.ResetColor(); //to change the color 
        }
    }
    
}
