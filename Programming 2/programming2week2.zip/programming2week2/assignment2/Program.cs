﻿using System;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[1-3] <nr of rows> <nr of columns>");
                return;
            }
            int numberOfRows = int.Parse(args[0]);
            int numberOfColumns = int.Parse(args[1]);
            Program myProgram = new Program();
            myProgram.Start(numberOfRows, numberOfColumns);

        }

        Random generator = new Random();

        //starting here
        void Start(int numberOfRows, int numberOfColumns)
        {
            int[,] matrix = new int[numberOfRows, numberOfColumns];
            int min = 1;
            int max = 100;
            //calling the methods
            InitMatrixRandom(matrix, min, max);
            DisplayMatrix(matrix);
            Console.WriteLine();

            //asking the user for the search number 
            Console.Write("Enter a number (to search for): ");
            int number = int.Parse(Console.ReadLine());
            Position firstNumber = SearchNumber(matrix, number);
            Console.WriteLine($"Number {number} is found (first) at position [{firstNumber.Row},{firstNumber.Column}]");
            Position lastNumber= SearchNumberBackwards(matrix, number);
            Console.WriteLine($"Number {number} is found (last) at position [{lastNumber.Row},{lastNumber.Column}]");
        }
        //filling in the array 
        void InitMatrixRandom(int[,] matrix, int min, int max)
        {
            
            for (int rows = 0; rows < matrix.GetLength(0); ++rows)
            {
                for (int columns = 0; columns < matrix.GetLength(1); ++columns)
                {
                    matrix[rows, columns] = generator.Next(min, max);
                }
            }
        }
        //displaying the array 
        void DisplayMatrix(int[,] matrix)
        {
            for (int rows = 0; rows < matrix.GetLength(0); rows++)
            {
                for (int columns = 0; columns < matrix.GetLength(1); columns++)
                {
                    Console.Write($"{matrix[rows, columns],2} ");
                }
                Console.WriteLine();
            }
        }

        //→ Create a  with two int values: row and column
        Position SearchNumber(int[,] matrix, int number)
        {
            for (int rows = 0; rows < matrix.GetLength(0); rows++)
            {
                for (int columns = 0; columns < matrix.GetLength(1); columns++)
                {
                    if (number == matrix[rows, columns])
                    {
                        Position position = new Position();
                        position.Row = rows;
                        position.Column = columns;
                        return position;
                    }
                }
            }
            return null;
        }
        Position SearchNumberBackwards(int[,] matrix, int number) 
        {
            for (int rows = matrix.GetLength(0) - 1; rows >= 0; rows--) // subtracting to come down 
            {
                for (int columns = matrix.GetLength(1) - 1; columns >=0; columns--) // subtracting to come down 
                {
                    if (number == matrix[rows, columns])
                    {
                        Position position = new Position();
                        position.Row = rows;
                        position.Column = columns;
                        return position;
                    }
                }
            }
            return null;
        }
    }
    
}
