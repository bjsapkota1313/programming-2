﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3
{
    public enum RegularCandies
    {
        JellyBean, Lozenge, LemonDrop, GumSquare, LollipopHead, Jujubecluster
    }
}
