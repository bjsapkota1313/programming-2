﻿using System;

namespace assignment3
{ 
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[1-3] <nr of rows> <nr of columns>");
                return;
            }
            int numberOfRows = int.Parse(args[0]);
            int numberOfColumns = int.Parse(args[1]);
            Program myProgram = new Program();
            myProgram.Start(numberOfRows, numberOfColumns);
        }
        void Start(int numberOfRows, int numberOfColumns)
        {
            RegularCandies[,] playingField =  new RegularCandies[numberOfRows, numberOfColumns];
            InitCandies(playingField);
            DisplayCandies(playingField);
            Console.WriteLine();
            if ( ScoreRowPresent(playingField))
            {
                Console.WriteLine("row score");
            }
            else
            {
                Console.WriteLine("no row score");
            }
            if (ScoreColumnPresent(playingField))
            {
                Console.WriteLine("column score");
            }
            else
            {
               Console.WriteLine("no column score");
            }

        }
        void InitCandies(RegularCandies[,] playingField)
        {
            Random generator = new Random();
            for (int rows = 0; rows < playingField.GetLength(0); rows++)
            {
                for (int columns = 0; columns < playingField.GetLength(1); columns++)
                {
                  int number = generator.Next(0,6);
                    playingField[rows, columns] = (RegularCandies)number;
                    //Console.Write(playingField[rows,columns]+" " ); to check
                }
               // Console.WriteLine();
            }
        }
        void DisplayCandies(RegularCandies[,] playingField)
        {
            for (int rows = 0; rows < playingField.GetLength(0); rows++)
            {
                for (int columns = 0; columns < playingField.GetLength(1); columns++)
                {
                    if (playingField[rows, columns] == RegularCandies.JellyBean)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    else if (playingField[rows, columns] == RegularCandies.Lozenge)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow; // orange color to implement
                    }
                    else if (playingField[rows, columns] == RegularCandies.LemonDrop)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                    }
                    else if (playingField[rows, columns] == RegularCandies.GumSquare)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                    }
                    else if (playingField[rows, columns] == RegularCandies.LollipopHead)
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkGray;
                    }
                    Console.Write("# ");
                }
                    Console.WriteLine();
            }
            Console.ResetColor();
        }
        bool ScoreRowPresent(RegularCandies[,] playingField)
        {
            for (int rows = 0; rows < playingField.GetLength(0); rows++)
            {
               int counter = 1;
                for (int columns = 0; columns < playingField.GetLength(1)-1; columns++)
                {
                    if (playingField[rows,columns]==playingField[rows,columns+1])
                    {
                        counter++;
                        if (counter>=3)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        counter = 1;
                    }

                }
            }
            return false;
        }
        bool ScoreColumnPresent(RegularCandies[,] playingField)
        {
            for (int columns = 0; columns < playingField.GetLength(1); columns++)
            {
                int counter = 1;
                for (int rows = 0; rows < playingField.GetLength(0)-1 ; rows++)
                {
                    
                    if (playingField[rows, columns] == playingField[rows+1, columns])
                    {
                        counter++;
                        if (counter >= 3)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        counter = 1;
                    }
                }
            }
            return false;
        }
    }
    
    
}
