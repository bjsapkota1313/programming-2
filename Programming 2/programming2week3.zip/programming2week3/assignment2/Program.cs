﻿using System;
 using System.Collections.Generic;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        void Start()
        {
             HangmanGame hangman = new HangmanGame();
            List<string> words = ListOfWords();
            hangman.secretWord = SelectWord(words);
               hangman.Init(hangman.secretWord);
            //Console.WriteLine($"The secret word is: {hangman.secretWord}");
            ////Console.WriteLine($"The guessed word is: {hangman.guessedWord}");
            //DisplayWord(hangman.guessedWord);
            if (PlayHangman(hangman))
            {
                Console.WriteLine("You guessed the word");
            }
            else
            {
                Console.WriteLine("Too bad, you did not guess the word ({0})",hangman.secretWord);
            }
        }
        List<string> ListOfWords()
        {
            List<string> words = new List<string>();
            words.Add("airplane");
            words.Add("kitchen");
            words.Add("building");
            words.Add("incredible");
            words.Add("funny");
            words.Add("trainstation");
            words.Add("neighbour");
            words.Add("different");
            words.Add("department");
            words.Add("planet");
            words.Add("presentation");
            words.Add("embarrassment");
            words.Add("integration");
            words.Add("scenario");
            words.Add("discount");
            words.Add("management");
            words.Add("understanding");
            words.Add("registration");
            words.Add("security");
            words.Add("language");
            return words;
        }
        string SelectWord(List<string> words)
        {
            Random generator = new Random();
           string secretWord = (words)[generator.Next(0,20)];
            return secretWord;
        }
        bool PlayHangman(HangmanGame hangman)
        {
            int maximumAttempts = 8;
            List<char> enteredLetters = new List<char>();
            while (!hangman.IsGuessed() && maximumAttempts!=0)
            {
                char newCheck  = ReadLetter(enteredLetters);
                enteredLetters.Add(newCheck);
                if (hangman.ContainsLetter(newCheck))
                {
                    //hangman.ContainsLetter(newCheck);
                    hangman.ProcessLetter(newCheck);
                }
                else
                {
                    maximumAttempts--;
                }
                DisplayLetters(enteredLetters);
                
                Console.WriteLine("Attempts left: {0}",maximumAttempts) ;
                Console.WriteLine();
                DisplayWord(hangman.guessedWord);
                Console.WriteLine();
            }
            if (hangman.IsGuessed())
            {
                return true;
            }
            return false;
        }
        void DisplayWord(string word)
        {
            Console.WriteLine(word); 
        }
        void DisplayLetters(List<char> letters)
        {
            Console.Write("Entered letters: ");
            for (int i = 0; i < letters.Count; i++)
            {
                Console.Write(letters[i] + " ");
            }
            Console.WriteLine();

        }
        char ReadLetter(List<char> blacklistLetters)
        {
            char letter;
             do
             {
                Console.Write("Enter a letter: ");
                letter = char.Parse(Console.ReadLine());
             } while (blacklistLetters.Contains(letter));
            return letter; 
        }
       
    }
}
