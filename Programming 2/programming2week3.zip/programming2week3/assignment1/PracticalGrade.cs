﻿namespace assignment1
{ 
    enum PracticalGrade
    {
        None,Absent,Insuffcient,Sufficient,Good
    }
}
