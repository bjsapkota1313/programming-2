﻿using System;
using System.Collections.Generic;

namespace assignment1
{ 
    class Program
    {
        const int NrOfCourses = 3;
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        void Start()
        {  
            
            List<Course> gradeList = ReadGradeList(NrOfCourses);
            DisplayGradeList(gradeList);
        }
        
        PracticalGrade ReadPracticalGrade(string question)
        {
            for (int i = 0; i < Enum.GetValues(typeof(PracticalGrade)).Length; ++i)
            {
                Console.Write($"{i}. {(PracticalGrade)i}  ");
            }
            Console.Write("\n" + question);
            Console.ForegroundColor = ConsoleColor.Green;
            int practicalGrade = int.Parse(Console.ReadLine());
            Console.ResetColor();
            PracticalGrade convertedPracticalGrade = (PracticalGrade)practicalGrade;
            return convertedPracticalGrade;
        }
        void DisplayPracticalGrade(PracticalGrade practical)
        {
            Console.Write(practical); 
        }
        Course ReadCourse(string question)
        {
            Course course = new Course();
            Console.WriteLine(question);
            course.Name = ReadString("Name of the course: ");
            course.TheoryGrade = ReadInt($"Theory Grade for {course.Name}: ");
            course.PracticalGrade = ReadPracticalGrade($"Practical grade for {course.Name}: ");
            Console.WriteLine();
            return course; 
        } 
        void DisplayCourse(Course course)
        {
            Console.Write($"{course.Name} : {course.TheoryGrade}  ");
            DisplayPracticalGrade(course.PracticalGrade);
            Console.WriteLine();
        }
        int ReadInt(string question)
        {
            Console.Write(question);
            Console.ForegroundColor = ConsoleColor.Green;
            int value = int.Parse(Console.ReadLine());
            Console.ResetColor();
           
            return value;
        }
        String ReadString(string question)
        {
            Console.Write(question);
            Console.ForegroundColor = ConsoleColor.Green;
            string readstring = Console.ReadLine();
            Console.ResetColor();
            return readstring;
        }
        List<Course> ReadGradeList(int nrOfCourses)
        {
            List<Course>gradelist = new List<Course>();
            for (int i = 0; i < NrOfCourses; ++i)
            {
                gradelist.Add(ReadCourse("Enter a course. "));
            }
            return gradelist;
        }
        void DisplayGradeList(List<Course> gradeList)
        {
            int passedSubject = 0;
            int cumLaude = 0;
            //Course course = new Course();
            foreach  (Course course in gradeList)
            {
                //DisplayPracticalGrade(gradeList[i].PracticalGrade);
                DisplayCourse(course);
                if (course.CumLaude())
                {
                    cumLaude++;
                }
                if (course.Passed())
                {
                    passedSubject++;  
                }
                
            }
            if (cumLaude==3)
            {
                Console.WriteLine("Congratulations, you graduated Cum Laude!");
            }
            else if (passedSubject==3)
            {
                Console.WriteLine("Congratulations,You graduated!");
            }
            else
            {
                Console.WriteLine($"Too bad, you did not graduate, you got {NrOfCourses-passedSubject} retakes.");
            }
        }


    }
}
