﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment1
{
    class Course
    {
        public string Name;
        public int TheoryGrade;
        public PracticalGrade PracticalGrade;
        public bool Passed()
        {
           return (TheoryGrade >= 55 && (PracticalGrade == PracticalGrade.Sufficient | PracticalGrade == PracticalGrade.Good));
        }
        public bool CumLaude()
        {
           return (TheoryGrade >= 80 && PracticalGrade == PracticalGrade.Good);
        }
    }
    
}
