﻿using System;

namespace assignment1
{

    class Program
    {
        static void Main()
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        void Start()
        {
            //Month month = Month.January; (Testing)
            //PrintMonth(month);

            PrintMonths();
            Month month = ReadMonth("Enter a Month number: ");
            Console.Write((int)month + " => ");
            PrintMonth(month);
        }
        void PrintMonth(Month month)
        {
            Console.WriteLine(month);
        }
        void PrintMonths()
        {
            Month month = Month.January;

            for (int i = 1; i <= 12; i++)
            {
                Console.Write($"{i,3}. ");
                PrintMonth(month);
                month++;
            }

            Console.WriteLine();
        }

        Month ReadMonth(string question)
        {
            int monthNumber;
            while (true)
            {
                Console.Write(question);
                monthNumber = int.Parse(Console.ReadLine());

                // Checking the enum 
                if (!Enum.IsDefined(typeof(Month), monthNumber))
                {
                    Console.WriteLine($"{monthNumber} is not a valid value.");
                }
                else
                {
                    break;
                }

            }
            Month convertedMonth = (Month)monthNumber;

            //Console.WriteLine(convertedMonth);  //just to check for Now
            return convertedMonth;
        }
    }
}
