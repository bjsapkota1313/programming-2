﻿namespace assignment1
{
   public enum Month
   {
       January = 1, February, March, April, May, June, July, August, September, October, November, December
    }
}
