﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment3
{
    class YahtzeeGame
    {
        Dice[] dices = new Dice[5];
        public void Init()
        {
            for (int i = 0; i < dices.Length; ++i)
            {
                dices[i] = new Dice();
            }
        }
        public void Throw()
        {
            foreach (Dice dice in dices)
            {
                dice.Throw();
            }
        }
        public void DisplayValues()
        {
            foreach (Dice dice in dices)
            {
                dice.DisplayValue();
                Console.Write(" ");
            }
            Console.WriteLine();
        }
        public bool Yahtzee()
        {
            int firstDiceValue = dices[0].value;
            for (int i = 1; i < dices.Length;i++)
            {
                if (dices[i].value != firstDiceValue)
                {
                    return false;
                }
            }
            return true;
        }

    }
}
