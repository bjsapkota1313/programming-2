﻿using System;

namespace assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        //starting
        void Start()
        {
            //Dice d1 = new Dice(); // dice 1
            //d1.Throw();
            //d1.DisplayValue();

            YahtzeeGame yahtzeeGame = new YahtzeeGame();
            yahtzeeGame.Init();

            int counter = 0;
            do
            {
                counter++;
                yahtzeeGame.Throw(); // throw dices
                yahtzeeGame.DisplayValues();
            }
            while (!yahtzeeGame.Yahtzee());
            //to display the no of times yathzee

            Console.WriteLine("Number of attempts needed (for Yahtzee): " + counter);

        }
    }
}
