﻿using System;

namespace assignment2
{
    //enum for Gender
    public enum GenderType
    {
        Male, Female
    }
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        //starting
        void Start()
        {
            Person[] persons = new Person[3];  //creating array
            for (int i = 0; i < persons.Length; i++)
            {
                persons[i] = ReadPerson();
                Console.WriteLine();
            }
            for (int i = 0; i < persons.Length; i++)
            {
                PrintPerson(persons[i]);
                Console.WriteLine();
            }
        }

        // for read all the strings 
        string ReadString(string question)
        {
            Console.Write(question);
            string name = Console.ReadLine();
            return name;
        }

        //for reading integers
        int ReadAge(string question)
        {
            Console.Write(question);
            int age = int.Parse(Console.ReadLine());
            return age;
        }

        //for reading the gendertype 
        GenderType ReadGender(string question)
        {
            Console.Write(question);
            string inputGender = Console.ReadLine();
            GenderType genderType;
            if (inputGender == "m")
            {
                genderType = GenderType.Male;
            }
            else 
            {
                genderType = GenderType.Female;
            }
            return genderType;
        }

        // for all personal information 
        Person ReadPerson()
        {
            Person p = new Person();
            p.FirstName = ReadString("Enter first name: ");
            p.LastName = ReadString("Enter last name: ");
            p.GenderType = ReadGender("Enter a gender(m/f): ");
            p.Age = ReadAge("Enter age: ");
            p.City = ReadString("Enter city: ");
           
            return p;
        }
        
        //to print 
        void PrintPerson(Person p)
        {
            Console.Write($"{p.FirstName} { p.LastName}");
            PrintGender(p.GenderType);
            Console.WriteLine($"{p.Age} years old, {p.City}");
        }
        void PrintGender(GenderType gender)
        {
            string printLabel;
            if (gender == GenderType.Male)
            {
                printLabel = "m";
            }
            else
            {
                printLabel = "f";
            }
            Console.WriteLine($" ({printLabel})");
        }
    }
}
