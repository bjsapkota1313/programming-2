﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment2
{
    class HangmanGame
    {
        public string secretWord;
        public string guessedWord;
        public void Init(string secretWord)
        {
            for (int i = 0; i < secretWord.Length; i++)
            {
                guessedWord = "." + guessedWord;
            }
        }
        public bool ContainsLetter(char letter)
        {
            foreach (char c in secretWord)
            {
                if (c == letter)
                {
                    return true;
                }
            }
            return false;
        }
        public void ProcessLetter(char letter)
        {
            for (int i = 0; i < secretWord.Length; i++)
            {
                if (secretWord[i] == letter)
                {
                    StringBuilder checkLetter = new StringBuilder(guessedWord);
                    checkLetter[i] = letter;
                    guessedWord = checkLetter.ToString();

                }
            }
        }
        public bool IsGuessed()
        {
            if (secretWord == guessedWord)  
            {
                return true;
            }
            return false;
        }
    }
}

