﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment1
{
    class Person
    {
         public string Name;
         public string City;
         public int Age;

    }
}
