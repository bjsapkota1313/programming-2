﻿using System;
using System.IO;

namespace assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        void Start()
        {
            Console.Write("Enter Your name: ");
            string name = Console.ReadLine();
            string filename = $"{name}";
            if (File.Exists(name))
            {
                Console.WriteLine($"Nice to see you again, {name}!");
                Console.WriteLine("We have the following  information about you: ");
                Person p = ReadPerson(filename);
                DisplayPerson(p);
            }
            else
            {
                Console.WriteLine("welcome");
                Person p = ReadPerson();
                WritePerson(p,filename);
                Console.WriteLine("Your data is written to file. ");
            }
        }
        Person ReadPerson()
        {
            Person p = new Person();
            Console.Write("Enter your name: ");
            p.Name = Console.ReadLine();
            //Console.WriteLine($"Welcome {person.Name}");
            Console.Write("Enter your city: ");
            p.City=Console.ReadLine();
            Console.Write("Enter your age: ");
            p.Age = int.Parse(Console.ReadLine());
            Console.ReadLine();
            
            return p;
        }
        void DisplayPerson(Person p)
        {
            Console.WriteLine("Name      :{0}",p.Name);
            Console.WriteLine("city      :{0}",p.City) ;
            Console.WriteLine("Age       :{0}",p.Age);
        }
        void WritePerson(Person p, string filename)
        {
            //to open file 
            StreamWriter writer = new StreamWriter(filename);
           
            writer.WriteLine(p.Name);
            writer.WriteLine(p.City);
            writer.WriteLine(p.Age);

            //to close the file 
            writer.Close();  
        }
        Person ReadPerson(string filename)
        {
            Person p = new Person();
            StreamReader reader = new StreamReader(filename);
            p.Name = reader.ReadLine();
            p.City=reader.ReadLine();
            p.Age=int.Parse(reader.ReadLine());
            reader.Close();
            return p;  
        }
    }
}
