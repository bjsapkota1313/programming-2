﻿using System;
using System.IO;

namespace assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[2-3] <filename>");
                return;
            }
            string filename = args[0];
            Program myProgram = new Program();
            myProgram.Start(filename);
        }
        void Start(string filename)
        {
            Console.Write("Enter a word (to search): ");
            string word = Console.ReadLine().ToUpper(); 
            Console.WriteLine($"Number of lines containing the word: {SearchWordInFile(filename, word)}"); 
        }
        bool WordInLine(string line, string word)
        {   
            if (line.ToUpper().Contains(word))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        int SearchWordInFile(string filename, string word)
        {
            int counter = 0;
            StreamReader reader = new StreamReader(filename);
            while (!reader.EndOfStream)
            {
               string line = reader.ReadLine(); 
               if (WordInLine(line, word))
               {
                    DisplayWordInLine(line, word);
                    counter++;
               }
            }
            reader.Close();
            return counter;
        }
        void DisplayWordInLine(string line, string word)
        {
           int nrOFLetterBeforeSearched= line.IndexOf(word, StringComparison.OrdinalIgnoreCase);// to make small and capital insensitive 
            Console.Write(line.Substring(0, nrOFLetterBeforeSearched));

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write($"[{line.Substring(nrOFLetterBeforeSearched, word.Length)}]"); // searched word 
            Console.ResetColor();

            Console.WriteLine(line.Substring(nrOFLetterBeforeSearched+word.Length));

        }

    }
}
