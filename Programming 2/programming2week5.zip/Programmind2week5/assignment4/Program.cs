﻿using System;
using System.Collections.Generic;
using System.IO;


namespace assignment4
{
    class Program
    {
        int attemptLeft = 5;
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[3-4] <filename>");
                return;
            }
            string filename = args[0];
            Program myProgram = new Program();
            myProgram.Start(filename);
        }
        void Start(string filename)
        {
            LingoGame lingoGame = new LingoGame();
            List<string> words;
            words = ReadWords(filename, 5);
            lingoGame.lingoWord = SelectWord(words);
            lingoGame.Init(lingoGame.lingoWord);
            //Console.WriteLine(lingoGame.lingoWord);
            if (PlayLingo(lingoGame))
            {
                Console.WriteLine("You have guessed the word!");
            }
            else
            {
                Console.WriteLine($"Too bad,you did not guess the word({lingoGame.lingoWord})");
            }
            
        }
        List<string> ReadWords(string filename, int WordLength)
        {
            List<string> words = new List<string>();
            StreamReader reader = new StreamReader(filename);
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                if (line.Length >= WordLength)
                {
                    words.Add(line);
                }
            }
            return words;
        }
        string SelectWord(List<string> words)
        {
            Random generator = new Random();
            string randomWord = (words)[generator.Next(0, words.Count)];
            return randomWord.ToUpper();
        }
        bool PlayLingo (LingoGame lingoGame)
        {
            int attempts = 0;                   //stg
            int wordLength = lingoGame.lingoWord.Length;
            while (attempts<attemptLeft && !lingoGame.WordGuessed())
            {
                lingoGame.playerWord = ReadPlayerWord(wordLength,++attempts);
                  Letterstate[] letterResults = lingoGame.ProcessWord(lingoGame.playerWord);
                DisplayPlayerWord(lingoGame.playerWord, letterResults);
            }
            return lingoGame.WordGuessed();
        }
        string ReadPlayerWord(int length,int attempts)
        {
            string word;
            do
            {
             Console.Write("Enter a ({0}) letter word, attempt {1}: ", length,attempts);
             word = Console.ReadLine();
            } while (word.Length!=length);
            return word.ToUpper();
        }
        void DisplayPlayerWord(string playerWord, Letterstate[] letterResults)//to 
        {
            for (int i = 0; i < playerWord.Length; i++)
            {
                if (letterResults[i]== Letterstate.Correct)
                {
                    Console.BackgroundColor = ConsoleColor.DarkGreen;
                }
                else if (letterResults[i] ==Letterstate.WrongPosition)
                {
                    Console.BackgroundColor = ConsoleColor.DarkYellow;
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                }

                Console.Write(playerWord[i]);
            }
            Console.ResetColor();
            Console.WriteLine();
        }
    }
}
