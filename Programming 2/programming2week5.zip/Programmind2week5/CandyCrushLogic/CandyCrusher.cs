﻿using System;

namespace CandyCrushLogic
{
    public class CandyCrusher
    {
         public static bool ScoreRowPresent(RegularCandies[,] playingField)
        {
            for (int rows = 0; rows < playingField.GetLength(0); rows++)
            {
                int counter = 1;
                for (int columns = 0; columns < playingField.GetLength(1) - 1; columns++)
                {
                    if (playingField[rows, columns] == playingField[rows, columns + 1])
                    {
                        counter++;
                        if (counter >= 3)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        counter = 1;
                    }
                }
            }
            return false;
        }
        public static bool  ScoreColumnPresent(RegularCandies[,] playingField)
        {
            for (int columns = 0; columns < playingField.GetLength(1); columns++)
            {
                int counter = 1;
                for (int rows = 0; rows < playingField.GetLength(0) - 1; rows++)
                {

                    if (playingField[rows, columns] == playingField[rows + 1, columns])
                    {
                        counter++;
                        if (counter >= 3)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        counter = 1;
                    }
                }
            }
            return false;
        }
    }
}
