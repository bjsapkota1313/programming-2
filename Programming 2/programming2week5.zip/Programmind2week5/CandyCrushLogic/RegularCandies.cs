﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CandyCrushLogic
{
    public enum RegularCandies
    {
        JellyBean, Lozenge, LemonDrop, GumSquare, LollipopHead, Jujubecluster
    }
}
