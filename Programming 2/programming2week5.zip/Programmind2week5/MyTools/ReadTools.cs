﻿using System;

namespace MyTools
{
    public class ReadTools
    {
        public static int ReadInt(string question)
        {
            Console.Write(question);
            int value = int.Parse(Console.ReadLine());
            return value;
        }
        public static int ReadInt(string question, int min, int max)
        {
            int checkingValue = ReadInt(question);
            while (checkingValue < min || checkingValue > max)
            {
                checkingValue = ReadInt(question);
            }
            return checkingValue;
        }
        public static string ReadString(string question)
        {
            Console.Write(question);
            string name = Console.ReadLine();
            return name;
        }
    }
}
