﻿using System;
using CandyCrushLogic;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[1-3] <nr of rows> <nr of columns>");
                return;
            }
            int numberOfRows = int.Parse(args[0]);
            int numberOfColumns = int.Parse(args[1]);
            Program myProgram = new Program();
            myProgram.Start(numberOfRows, numberOfColumns);
        }
         public void Start(int numberOfRows, int numberOfColumns)
        {
            RegularCandies[,] playingField = new RegularCandies[numberOfRows, numberOfColumns];
            InitCandies(playingField);
            DisplayCandies(playingField);
            Console.WriteLine();
            if (CandyCrusher.ScoreRowPresent(playingField))
            {
                Console.WriteLine("row score");
            }
            else
            {
                Console.WriteLine("no row score");
            }
            if (CandyCrusher.ScoreColumnPresent(playingField))
            {
                Console.WriteLine("column score");
            }
            else
            {
                Console.WriteLine("no column score");
            }
        }
        void InitCandies(RegularCandies[,] playingField)
        {
            Random generator = new Random();
            for (int rows = 0; rows < playingField.GetLength(0); rows++)
            {
                for (int columns = 0; columns < playingField.GetLength(1); columns++)
                {
                    int number = generator.Next(0, 6);
                    playingField[rows, columns] = (RegularCandies)number;
                    //Console.Write(playingField[rows,columns]+" " ); to check
                }
                // Console.WriteLine();
            }
        }
        void DisplayCandies(RegularCandies[,] playingField)
        {
            for (int rows = 0; rows < playingField.GetLength(0); rows++)
            {
                for (int columns = 0; columns < playingField.GetLength(1); columns++)
                {
                    switch (playingField[rows, columns])
                    {
                        case RegularCandies.JellyBean :
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;

                        case RegularCandies.Lozenge:
                         Console.ForegroundColor = ConsoleColor.DarkYellow;
                         break;
                        case RegularCandies.LemonDrop:
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            break;
                        case RegularCandies.LollipopHead:
                            Console.ForegroundColor = ConsoleColor.Green;
                            break;
                        case RegularCandies.Jujubecluster:
                            Console.ForegroundColor = ConsoleColor.Blue;
                            break;
                        default:
                            Console.ForegroundColor = ConsoleColor.DarkGray;
                            break;
                    }      
                    Console.Write("# ");
                }
                Console.WriteLine();
            }
            Console.ResetColor();
        }
    }
    
       
    
}
