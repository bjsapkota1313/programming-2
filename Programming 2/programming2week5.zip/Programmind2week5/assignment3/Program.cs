﻿using System;
using System.Collections.Generic;
using System.IO;

namespace assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[3-4] <filename>");
                return;
            }
            string filename = args[0];
            Program myProgram = new Program();
            myProgram.Start(filename);
        }
        void Start(string filename)
        {
            TranslateWords(ReadWords(filename));

        }
        Dictionary<string, string> ReadWords(string filename)
        {
            Dictionary<string, string> dict = new Dictionary<string,string>();
            StreamReader reader = new StreamReader(filename);
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                string[] words = line.Split(';');    
                string dictionaryKey = words[0];
                 string dictonaryWord= words[1];
                dict.Add(dictionaryKey, dictonaryWord);
            }
            reader.Close();
            return dict;
        }
        void TranslateWords(Dictionary<string, string> words)
        {
            string word;
            do
            {
              Console.Write("Enter a Word: ");
              word = Console.ReadLine();
              if (words.ContainsKey(word))
              {
               Console.ForegroundColor = ConsoleColor.Green;
               Console.WriteLine($"{word} => {words[word]}");
               Console.ResetColor();
              }
              else if (word.ToUpper() == "LISTALL")
              {
                    ListAllWords(words);
              }
              else
              {
                    Console.WriteLine("word '{0}' not found",word);
              }

            } while (word.ToUpper()!= "STOP");
        }
        void ListAllWords(Dictionary<string, string> words)
        {
            Dictionary<string, string>.KeyCollection KeyWords = words.Keys;
            foreach (var keyWord in KeyWords)
            {

                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"{keyWord} => {words[keyWord]}");
                Console.ResetColor();
            }
                
        }

    }
}
